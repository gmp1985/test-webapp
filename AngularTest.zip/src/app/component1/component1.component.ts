import { Component, OnInit, AfterViewInit } from '@angular/core';
import { JsonServiceService } from '../services/json-service.service';

@Component({
  selector: 'app-component1',
  templateUrl: './component1.component.html',
  styleUrls: ['./component1.component.css']
})
export class Component1Component implements OnInit {

  public jsonVal: any;
  public allVal: any;
  public iterate: number = 0;
  public ans: any;
  public ansDisp: any;
  public subBtn: boolean = true;
  public correctAns: any;
  public score: number = 0;
  public total: number;
  constructor(private jsonService: JsonServiceService) { }

  ngOnInit() {    
    this.jsonService._getJsonData('./assets/data/jsondata.json').subscribe((data : any ) => {      
      this.allVal = data;
      this.jsonVal = data[this.iterate]; 
      this.subBtn = false;
      
      this.findCorrectAns(data[this.iterate]);
      this.total = data.length;       
    });       
  }

  findCorrectAns(data: any){    
    for(let i = 0; i<data.options.length; i++){
      if(data.options[i].iscorrect == true){
       this.correctAns = data.options[i].option; 
      } 
    }
  }

  selectAns(){    
    this.ans = (event.target as HTMLOptionElement).value;
    
    if(this.subBtn == false){
      document.querySelector("#subBtn").removeAttribute('disabled');
    }       
  }

  submitAns(){
    if(this.ans == 'true'){
      this.ansDisp = "Correct";
      this.score++;
    }
    else{
      this.ansDisp = "Wrong!"
    }

    this.subBtn = true;
    document.querySelector("#subBtn").setAttribute('disabled','disabled');
  }

  nextAns(){        
    if(this.allVal.length-1 == (this.iterate+1)){
      document.querySelector("#nextBtn").setAttribute('disabled','disabled');
    }
    
    if(this.allVal.length != (this.iterate+1)){
      ++this.iterate;
      this.jsonVal = this.allVal[this.iterate];
      this.findCorrectAns(this.allVal[this.iterate]);

      this.ansDisp = '';
      this.subBtn = false;
      document.querySelector("#subBtn").setAttribute('disabled','disabled');
    }    
  }
}
